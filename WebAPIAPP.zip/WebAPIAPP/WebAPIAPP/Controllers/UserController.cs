﻿using LoggerService;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Web.Helpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using WebAPIAPP.Helper;
using WebAPIAPP.Model;
using WebAPIAPP.Services;
using WebAPIAPP.ViewModels;

namespace WebAPIAPP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IUserService _userService;
        ILoggerManager _logger;
        public UserController(IUserService service, ILoggerManager logger)
        {
            _userService = service;
            _logger = logger;
        }

        /// <summary>
        /// Get all Users
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetUsers([FromQuery] UserParameters userParameters)
        {
            try
            {
                var users = _userService.GetUsers(userParameters);
                if (users == null || users?.Count == 0) return NotFound();
                return Ok(users);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        ///// <summary>
        ///// Search Users by User ID
        ///// </summary>
        ///// <returns></returns>
        //[HttpGet]
        //[Route("[action]")]
        //public IActionResult SearchUsersByUserId(string searchUsers, int pageNumber, int pageSize = 10)
        //{
        //    try
        //    {
        //        var users = _userService.GetUsers(searchUsers, pageNumber, pageSize);
        //        if (users == null || users?.Count == 0) return NotFound();
        //        return Ok(users);
        //    }
        //    catch (Exception)
        //    {
        //        return BadRequest();
        //    }
        //}

        /// <summary>
        /// Get Users details by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("[action]/id")]
        public IActionResult GetUsersById(string id)
        {
            try
            {
                var users = _userService.GetUserDetailsById(id);

                if (users == null) return NotFound();
                return Ok(users);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        /// <summary>
        /// save user
        /// </summary>
        /// <param name="userModel"></param>

        /// <returns code="200"> User created sucesfully</returns>
        /// <returns code="400"> Bad Request</returns>
        [HttpPost]
        public IActionResult SaveUsers([FromForm] Users userModel)
        {
            try
            {
                var model = _userService.SaveUser(userModel);
                return Ok(model);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        /// <summary>
        /// delete user
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("[action]")]
        public IActionResult DeleteUser(string id)
        {
            try
            {
                var model = _userService.DeleteUser(id);
                return Ok(model);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

      
    }
}
