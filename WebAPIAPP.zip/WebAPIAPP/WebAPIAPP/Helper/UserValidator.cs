﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIAPP.Model;

namespace WebAPIAPP.Helper
{
    public class UserValidator : AbstractValidator<Users>
    {
        /// <summary>  
        /// Validator rules for User  
        /// </summary>  
        /// 
        public UserValidator()
        {
            RuleFor(x => x.UserId)
                .NotEmpty()
                .WithMessage("UserId should not be empty");

            RuleFor(x => x.FullAddress)
                .NotEmpty()
                .WithMessage("Address should not be empty");

            RuleFor(x => x.Name)
                .NotEmpty()
                .NotNull()
                .WithMessage("Name should not be null or empty");

            RuleFor(x => x.JoiningDate)
                .NotNull()
                .NotEmpty()
                .WithMessage("JoiningDate should not be null or empty");
                

            RuleFor(x => x.Country)
                .NotNull()
                .NotEmpty()
                .WithMessage("Country should not be null of empty");

            RuleFor(x => x.Designation)
                .NotNull()
                .NotEmpty()
                .WithMessage("Designation should not be null of empty");


        }
    }
}
