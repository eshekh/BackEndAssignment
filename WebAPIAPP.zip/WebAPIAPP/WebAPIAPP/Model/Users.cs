﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WebAPIAPP.Helper;
using FluentValidation;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebAPIAPP.Model
{
    public class Users
    {
        /// <summary>
        /// User Id
        /// </summary>
        [Key]
        public string UserId { get; set; }
        /// <summary>
        /// User Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// User Desgination
        /// </summary>
        public string Designation { get; set; }
        /// <summary>
        /// User Joining Date
        /// </summary>
        public DateTime JoiningDate { get; set; }
        /// <summary>
        /// User Full address
        /// </summary>
        public string FullAddress { get; set; }
        /// <summary>
        /// User Country
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// Image of User
        /// </summary>
        public string ImagePath { get; set; }

        [NotMapped]
        public IFormFile Image { get; set; }

    }
}
