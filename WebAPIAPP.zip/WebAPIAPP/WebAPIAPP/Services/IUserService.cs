﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIAPP.Helper;
using WebAPIAPP.Model;
using WebAPIAPP.ViewModels;

namespace WebAPIAPP.Services
{
    public interface IUserService
    {
        /// <summary>
        /// get list of all users
        /// </summary>
        /// <returns></returns>
        List<Users> GetUsers(UserParameters userParameters);
             

        /// <summary>
        /// get user details by user id
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        Users GetUserDetailsById(string userId);

        /// <summary>
        ///  add edit user
        /// </summary>
        /// <param name="userModel"></param>
        /// <returns></returns>
        ResponseModel SaveUser(Users userModel);


        /// <summary>
        /// delete users
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        ResponseModel DeleteUser(string userId);
    }
}
