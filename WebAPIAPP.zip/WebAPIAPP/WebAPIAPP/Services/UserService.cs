﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using WebAPIAPP.Helper;
using WebAPIAPP.Model;
using WebAPIAPP.ViewModels;

namespace WebAPIAPP.Services
{
    public class UserService : IUserService
    {
        private ISortHelper<Users> _sortHelper;
        private UserContext _context;
        public UserService(UserContext context, ISortHelper<Users> sortHelper)
        {
            _context = context;
            _sortHelper = sortHelper;
        }
        public ResponseModel DeleteUser(string userId)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                Users _user = GetUserDetailsById(userId);
                if (_user != null)
                {
                    _context.Remove<Users>(_user);
                    _context.SaveChanges();
                    model.IsSuccess = true;
                    model.Messsage = "User Deleted Successfully";
                }
                else
                {
                    model.IsSuccess = false;
                    model.Messsage = "User Not Found";
                }
            }
            catch (Exception ex)
            {
                model.IsSuccess = false;
                model.Messsage = "Error : " + ex.Message;
            }
            return model;
        }

        /// <summary>
        /// get user details by user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public Users GetUserDetailsById(string userId)
        {
            Users user;
            try
            {
                user = _context.Find<Users>(userId);
            }
            catch (Exception)
            {
                throw;
            }
            return user;
        }


        /// <summary>
        /// get user details search by userid
        /// </summary>
        /// <param name="UserParameters"></param>
        /// <returns></returns> 
        public List<Users> GetUsers(UserParameters userParameters)
        {
            List<Users> userList;
            try
            {
                var users = _context.Set<Users>().AsNoTracking();
                //Apply Search
                SearchByUserId(ref users, userParameters.UserId);
                //Apply Sorting
                var sortedUsers = _sortHelper.ApplySort(users, userParameters.OrderBy);
                //Apply Paging
                userList = PagedList<Users>.ToPagedList(sortedUsers, userParameters.PageNumber, userParameters.PageSize);

            }
            catch (Exception)
            {
                throw;
            }
            return userList;
        }

        public ResponseModel SaveUser(Users userModel)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                var _users = GetUserDetailsById(userModel.UserId);
                if (_users != null)
                {
                    _users.Designation = userModel.Designation;
                    _users.Name = userModel.Name;
                    _users.JoiningDate = userModel.JoiningDate;
                    _users.FullAddress = userModel.FullAddress;
                    _users.Country = userModel.Country;
                    _users.ImagePath = SaveImage(userModel.Image);

                    _context.Update<Users>(_users);
                    model.Messsage = "User Update Successfully";
                }
                else
                {
                    userModel.ImagePath = SaveImage(userModel.Image);
                    _context.Add<Users>(userModel);
                    model.Messsage = "User Added Successfully";
                }
                _context.SaveChanges();
                model.IsSuccess = true;
            }
            catch (Exception ex)
            {
                model.IsSuccess = false;
                model.Messsage = "Error : " + ex.Message;
            }
            return model;
        }

        private void SearchByUserId(ref IQueryable<Users> users, string userid)
        {
            if (!users.Any() || string.IsNullOrWhiteSpace(userid))
                return;

            if (string.IsNullOrEmpty(userid))
                return;

            users = users.Where(o => o.UserId.ToLowerInvariant().Contains(userid.Trim().ToLowerInvariant()));
        }

        private string SaveImage(IFormFile file)
        {
            var folderName = Path.Combine("StaticFiles", "Images");
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

            if (file.Length > 0)
            {
                var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);
                var imagePath = Path.Combine(folderName, fileName);

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                return imagePath;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
